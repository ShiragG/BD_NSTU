﻿namespace Collective_Farm
{
    partial class Dogovor_T
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dogovor_T));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comBOrg = new System.Windows.Forms.ComboBox();
            this.comBUsP = new System.Windows.Forms.ComboBox();
            this.comBUsOpl = new System.Windows.Forms.ComboBox();
            this.comBKult = new System.Windows.Forms.ComboBox();
            this.texBObjem = new System.Windows.Forms.TextBox();
            this.texBPayforEd = new System.Windows.Forms.TextBox();
            this.butOk = new System.Windows.Forms.Button();
            this.butCancel = new System.Windows.Forms.Button();
            this.textBND = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dataBData = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Организация";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Условия доставки";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Условия оплаты";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Культура";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(276, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Объём";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(279, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Цена за ед. тов.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(276, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Дата поставки";
            // 
            // comBOrg
            // 
            this.comBOrg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBOrg.FormattingEnabled = true;
            this.comBOrg.Location = new System.Drawing.Point(25, 42);
            this.comBOrg.Name = "comBOrg";
            this.comBOrg.Size = new System.Drawing.Size(198, 21);
            this.comBOrg.TabIndex = 7;
            // 
            // comBUsP
            // 
            this.comBUsP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBUsP.FormattingEnabled = true;
            this.comBUsP.Location = new System.Drawing.Point(25, 84);
            this.comBUsP.Name = "comBUsP";
            this.comBUsP.Size = new System.Drawing.Size(198, 21);
            this.comBUsP.TabIndex = 8;
            // 
            // comBUsOpl
            // 
            this.comBUsOpl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBUsOpl.FormattingEnabled = true;
            this.comBUsOpl.Location = new System.Drawing.Point(25, 127);
            this.comBUsOpl.Name = "comBUsOpl";
            this.comBUsOpl.Size = new System.Drawing.Size(198, 21);
            this.comBUsOpl.TabIndex = 9;
            // 
            // comBKult
            // 
            this.comBKult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBKult.FormattingEnabled = true;
            this.comBKult.Location = new System.Drawing.Point(25, 171);
            this.comBKult.Name = "comBKult";
            this.comBKult.Size = new System.Drawing.Size(200, 21);
            this.comBKult.TabIndex = 10;
            // 
            // texBObjem
            // 
            this.texBObjem.Location = new System.Drawing.Point(279, 43);
            this.texBObjem.Name = "texBObjem";
            this.texBObjem.Size = new System.Drawing.Size(198, 20);
            this.texBObjem.TabIndex = 11;
            // 
            // texBPayforEd
            // 
            this.texBPayforEd.Location = new System.Drawing.Point(279, 84);
            this.texBPayforEd.Name = "texBPayforEd";
            this.texBPayforEd.Size = new System.Drawing.Size(198, 20);
            this.texBPayforEd.TabIndex = 12;
            // 
            // butOk
            // 
            this.butOk.Location = new System.Drawing.Point(402, 217);
            this.butOk.Name = "butOk";
            this.butOk.Size = new System.Drawing.Size(75, 23);
            this.butOk.TabIndex = 14;
            this.butOk.Text = "Ок";
            this.butOk.UseVisualStyleBackColor = true;
            this.butOk.Click += new System.EventHandler(this.butOk_Click);
            // 
            // butCancel
            // 
            this.butCancel.Location = new System.Drawing.Point(21, 217);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 15;
            this.butCancel.Text = "Отмена";
            this.butCancel.UseVisualStyleBackColor = true;
            this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // textBND
            // 
            this.textBND.Location = new System.Drawing.Point(279, 171);
            this.textBND.Name = "textBND";
            this.textBND.Size = new System.Drawing.Size(198, 20);
            this.textBND.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(276, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Номер договора";
            // 
            // dataBData
            // 
            this.dataBData.Location = new System.Drawing.Point(279, 131);
            this.dataBData.Name = "dataBData";
            this.dataBData.Size = new System.Drawing.Size(198, 20);
            this.dataBData.TabIndex = 18;
            // 
            // Dogovor_T
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 253);
            this.Controls.Add(this.dataBData);
            this.Controls.Add(this.textBND);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.butCancel);
            this.Controls.Add(this.butOk);
            this.Controls.Add(this.texBPayforEd);
            this.Controls.Add(this.texBObjem);
            this.Controls.Add(this.comBKult);
            this.Controls.Add(this.comBUsOpl);
            this.Controls.Add(this.comBUsP);
            this.Controls.Add(this.comBOrg);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dogovor_T";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Заполнение формы";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comBOrg;
        private System.Windows.Forms.ComboBox comBUsP;
        private System.Windows.Forms.ComboBox comBUsOpl;
        private System.Windows.Forms.ComboBox comBKult;
        private System.Windows.Forms.TextBox texBObjem;
        private System.Windows.Forms.TextBox texBPayforEd;
        private System.Windows.Forms.Button butOk;
        private System.Windows.Forms.Button butCancel;
        private System.Windows.Forms.TextBox textBND;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dataBData;
    }
}