﻿namespace Collective_Farm_Admin
{
    partial class AddUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddUser));
            this.butAdd = new System.Windows.Forms.Button();
            this.butCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textFN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textSN = new System.Windows.Forms.TextBox();
            this.textPN = new System.Windows.Forms.TextBox();
            this.textLog = new System.Windows.Forms.TextBox();
            this.textPas = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comBStatus = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comBGRab = new System.Windows.Forms.ComboBox();
            this.comBDogov = new System.Windows.Forms.ComboBox();
            this.comBAuto = new System.Windows.Forms.ComboBox();
            this.comBOrg = new System.Windows.Forms.ComboBox();
            this.comBPlan = new System.Windows.Forms.ComboBox();
            this.comBAvPay = new System.Windows.Forms.ComboBox();
            this.comBKult = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comBSit = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // butAdd
            // 
            this.butAdd.Location = new System.Drawing.Point(737, 279);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(75, 23);
            this.butAdd.TabIndex = 0;
            this.butAdd.Text = "Ок";
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // butCancel
            // 
            this.butCancel.Location = new System.Drawing.Point(640, 279);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 1;
            this.butCancel.Text = "Отмена";
            this.butCancel.UseVisualStyleBackColor = true;
            this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Фамилия";
            // 
            // textFN
            // 
            this.textFN.Location = new System.Drawing.Point(22, 106);
            this.textFN.Name = "textFN";
            this.textFN.Size = new System.Drawing.Size(136, 20);
            this.textFN.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Имя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Отчество";
            // 
            // textSN
            // 
            this.textSN.Location = new System.Drawing.Point(22, 150);
            this.textSN.Name = "textSN";
            this.textSN.Size = new System.Drawing.Size(136, 20);
            this.textSN.TabIndex = 6;
            // 
            // textPN
            // 
            this.textPN.Location = new System.Drawing.Point(22, 196);
            this.textPN.Name = "textPN";
            this.textPN.Size = new System.Drawing.Size(136, 20);
            this.textPN.TabIndex = 7;
            // 
            // textLog
            // 
            this.textLog.Location = new System.Drawing.Point(202, 106);
            this.textLog.Name = "textLog";
            this.textLog.Size = new System.Drawing.Size(127, 20);
            this.textLog.TabIndex = 8;
            // 
            // textPas
            // 
            this.textPas.Location = new System.Drawing.Point(202, 150);
            this.textPas.Name = "textPas";
            this.textPas.PasswordChar = '*';
            this.textPas.Size = new System.Drawing.Size(127, 20);
            this.textPas.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(202, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Логин";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(202, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Пароль";
            // 
            // comBStatus
            // 
            this.comBStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBStatus.FormattingEnabled = true;
            this.comBStatus.Items.AddRange(new object[] {
            "Администратор",
            "Пользователь"});
            this.comBStatus.Location = new System.Drawing.Point(202, 196);
            this.comBStatus.Name = "comBStatus";
            this.comBStatus.Size = new System.Drawing.Size(127, 21);
            this.comBStatus.TabIndex = 12;
            this.comBStatus.SelectedIndexChanged += new System.EventHandler(this.comBStatus_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(202, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Статус";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(434, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "График работ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(434, 133);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Автопарк";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(434, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "План хозяйства";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(638, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Договора";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(638, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Организации";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(638, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "Авансовые платежи";
            // 
            // comBGRab
            // 
            this.comBGRab.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBGRab.FormattingEnabled = true;
            this.comBGRab.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBGRab.Location = new System.Drawing.Point(434, 109);
            this.comBGRab.Name = "comBGRab";
            this.comBGRab.Size = new System.Drawing.Size(162, 21);
            this.comBGRab.TabIndex = 21;
            // 
            // comBDogov
            // 
            this.comBDogov.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBDogov.FormattingEnabled = true;
            this.comBDogov.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBDogov.Location = new System.Drawing.Point(638, 109);
            this.comBDogov.Name = "comBDogov";
            this.comBDogov.Size = new System.Drawing.Size(162, 21);
            this.comBDogov.TabIndex = 22;
            // 
            // comBAuto
            // 
            this.comBAuto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBAuto.FormattingEnabled = true;
            this.comBAuto.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBAuto.Location = new System.Drawing.Point(434, 149);
            this.comBAuto.Name = "comBAuto";
            this.comBAuto.Size = new System.Drawing.Size(162, 21);
            this.comBAuto.TabIndex = 23;
            // 
            // comBOrg
            // 
            this.comBOrg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBOrg.FormattingEnabled = true;
            this.comBOrg.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBOrg.Location = new System.Drawing.Point(638, 149);
            this.comBOrg.Name = "comBOrg";
            this.comBOrg.Size = new System.Drawing.Size(162, 21);
            this.comBOrg.TabIndex = 24;
            // 
            // comBPlan
            // 
            this.comBPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBPlan.FormattingEnabled = true;
            this.comBPlan.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBPlan.Location = new System.Drawing.Point(434, 189);
            this.comBPlan.Name = "comBPlan";
            this.comBPlan.Size = new System.Drawing.Size(162, 21);
            this.comBPlan.TabIndex = 25;
            // 
            // comBAvPay
            // 
            this.comBAvPay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBAvPay.FormattingEnabled = true;
            this.comBAvPay.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBAvPay.Location = new System.Drawing.Point(638, 189);
            this.comBAvPay.Name = "comBAvPay";
            this.comBAvPay.Size = new System.Drawing.Size(162, 21);
            this.comBAvPay.TabIndex = 26;
            // 
            // comBKult
            // 
            this.comBKult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBKult.FormattingEnabled = true;
            this.comBKult.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBKult.Location = new System.Drawing.Point(434, 239);
            this.comBKult.Name = "comBKult";
            this.comBKult.Size = new System.Drawing.Size(162, 21);
            this.comBKult.TabIndex = 28;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(434, 223);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 27;
            this.label14.Text = "Культуры";
            // 
            // comBSit
            // 
            this.comBSit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBSit.FormattingEnabled = true;
            this.comBSit.Items.AddRange(new object[] {
            "Полный доступ",
            "Чтение",
            "Чтение и добавление",
            "Чтение, добавление, редактирование",
            "Запрет"});
            this.comBSit.Location = new System.Drawing.Point(434, 281);
            this.comBSit.Name = "comBSit";
            this.comBSit.Size = new System.Drawing.Size(162, 21);
            this.comBSit.TabIndex = 30;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(434, 265);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "Участки";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(430, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(190, 19);
            this.label16.TabIndex = 31;
            this.label16.Text = "Планирование хозяйства";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(634, 49);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 19);
            this.label17.TabIndex = 32;
            this.label17.Text = "Документация";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(558, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 22);
            this.label7.TabIndex = 33;
            this.label7.Text = "Права доступа";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(103, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(152, 22);
            this.label18.TabIndex = 34;
            this.label18.Text = "Личные данные";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(335, 151);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(75, 17);
            this.checkBox1.TabIndex = 35;
            this.checkBox1.Text = "Показать";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // AddUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 311);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.comBSit);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.comBKult);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.comBAvPay);
            this.Controls.Add(this.comBPlan);
            this.Controls.Add(this.comBOrg);
            this.Controls.Add(this.comBAuto);
            this.Controls.Add(this.comBDogov);
            this.Controls.Add(this.comBGRab);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comBStatus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textPas);
            this.Controls.Add(this.textLog);
            this.Controls.Add(this.textPN);
            this.Controls.Add(this.textSN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textFN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.butCancel);
            this.Controls.Add(this.butAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавление пользователя";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.Button butCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textFN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textSN;
        private System.Windows.Forms.TextBox textPN;
        private System.Windows.Forms.TextBox textLog;
        private System.Windows.Forms.TextBox textPas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comBStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comBGRab;
        private System.Windows.Forms.ComboBox comBDogov;
        private System.Windows.Forms.ComboBox comBAuto;
        private System.Windows.Forms.ComboBox comBOrg;
        private System.Windows.Forms.ComboBox comBPlan;
        private System.Windows.Forms.ComboBox comBAvPay;
        private System.Windows.Forms.ComboBox comBKult;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comBSit;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}